$(document).ready(function(){
	$("#headerArea").load("templates.html .insideHeader", addActiveClass);
	$("#searchArea").load("templates.html .searchBarBg");
	$("#footerArea").load("templates.html .insideFooter");
	$("body").on("click",".searchBtn",function () {
		window.location.href = "search.html";
	})
	if($('#searchResultItems').is(':visible')){
		for(var i=0;i<3;i++){
			$('#searchResultItems').append($('.searchResult').eq(0).clone())
		}		
	}	
})

function addActiveClass(){
	var x = window.location.pathname.slice(1);
	$('a[href="'+x+'"]').eq(0).parent().addClass('live');
}